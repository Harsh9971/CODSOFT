Minimal full-stack e-commerce app (React + Node + MongoDB)

How to run:

Backend:
  cd backend
  npm install
  copy .env.example to .env and set values (MONGO_URI, JWT_SECRET, STRIPE_SECRET_KEY)
  npm run seed   # optional - seeds sample products
  npm run dev    # requires nodemon or use npm start

Frontend:
  cd frontend
  npm install
  copy .env.example to .env and set REACT_APP_API_URL and REACT_APP_STRIPE_PUBLISHABLE_KEY
  npm start

Notes:
- This is a minimal starting point for development and learning.
- In production you must add validations, error handling, https, webhooks for Stripe, and secure secrets.
