import React, { useEffect, useState, useContext } from 'react';
import { useParams } from 'react-router-dom';
import api from '../api/axios';
import { CartContext } from '../contexts/CartContext';

export default function ProductPage(){
  const { id } = useParams();
  const [product, setProduct] = useState(null);
  const { addToCart } = useContext(CartContext);

  useEffect(() => {
    (async ()=> {
      const { data } = await api.get(`/products/${id}`);
      setProduct(data);
    })();
  }, [id]);

  if (!product) return <div>Loading...</div>;
  return (
    <div>
      <h2>{product.title}</h2>
      <p>{product.description}</p>
      <p>₹{product.price}</p>
      <button onClick={()=>addToCart(product,1)}>Add to cart</button>
    </div>
  );
}
