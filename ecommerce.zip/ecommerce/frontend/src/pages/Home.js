import React, { useEffect, useState } from 'react';
import api from '../api/axios';
import ProductCard from '../components/ProductCard';
import FilterBar from '../components/FilterBar';

export default function Home() {
  const [products, setProducts] = useState([]);
  const [filters, setFilters] = useState({ page:1, limit:12, sort:'', category:'', brand:'', minPrice:'', maxPrice:'', search:'' });
  const [total, setTotal] = useState(0);

  useEffect(() => {
    (async () => {
      const { data } = await api.get('/products', { params: filters });
      setProducts(data.products);
      setTotal(data.total);
    })();
  }, [filters]);

  return (
    <div>
      <FilterBar filters={filters} setFilters={setFilters} />
      <div style={{display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(220px,1fr))', gap:16}}>
        {products.map(p => <ProductCard key={p._id} product={p} />)}
      </div>
      <p>Total: {total}</p>
    </div>
  );
}
