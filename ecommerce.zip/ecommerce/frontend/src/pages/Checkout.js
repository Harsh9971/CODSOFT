import React, { useContext, useMemo, useState } from 'react';
import api from '../api/axios';
import { CartContext } from '../contexts/CartContext';
import { loadStripe } from '@stripe/stripe-js';
import { Elements, CardElement, useStripe, useElements } from '@stripe/react-stripe-js';

const stripePromise = loadStripe(process.env.REACT_APP_STRIPE_PUBLISHABLE_KEY || '');

function CheckoutFormInner({ total }) {
  const stripe = useStripe();
  const elements = useElements();
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    const { data } = await api.post('/payments/create-payment-intent', { amount: total });
    const clientSecret = data.clientSecret;
    const res = await stripe.confirmCardPayment(clientSecret, {
      payment_method: { card: elements.getElement(CardElement) }
    });
    if (res.error) {
      alert(res.error.message);
      setLoading(false);
    } else {
      if (res.paymentIntent.status === 'succeeded') {
        await api.post('/orders', { items: JSON.parse(localStorage.getItem('cart') || '[]'), total, shippingAddress: {}, paymentIntentId: res.paymentIntent.id });
        alert('Payment successful!');
        localStorage.removeItem('cart');
        window.location.href = '/';
      }
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <CardElement />
      <button disabled={!stripe || loading}>Pay ₹{total}</button>
    </form>
  );
}

export default function CheckoutPage(){
  const { cart } = useContext(CartContext);
  const total = useMemo(() => cart.reduce((s, c) => s + c.price * c.qty, 0), [cart]);
  if (cart.length === 0) return <div>Your cart is empty</div>;

  return (
    <Elements stripe={stripePromise}>
      <h2>Checkout</h2>
      <CheckoutFormInner total={total} />
    </Elements>
  );
}
