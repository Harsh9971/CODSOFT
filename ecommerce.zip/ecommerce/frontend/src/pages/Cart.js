import React, { useContext } from 'react';
import { CartContext } from '../contexts/CartContext';
import { useNavigate } from 'react-router-dom';

export default function CartPage(){
  const { cart, removeFromCart } = useContext(CartContext);
  const navigate = useNavigate();
  const total = cart.reduce((s, c) => s + c.price * c.qty, 0);
  return (
    <div>
      <h2>Cart</h2>
      {cart.map(i => (
        <div key={i.product} style={{borderBottom:'1px solid #eee', padding:8}}>
          <p>{i.title} x {i.qty} - ₹{i.price * i.qty}</p>
          <button onClick={()=>removeFromCart(i.product)}>Remove</button>
        </div>
      ))}
      <p>Total: ₹{total}</p>
      <button onClick={()=>navigate('/checkout')}>Proceed to Checkout</button>
    </div>
  );
}
