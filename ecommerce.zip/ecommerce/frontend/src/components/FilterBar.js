import React from 'react';

export default function FilterBar({ filters, setFilters }) {
  return (
    <div style={{display:'flex', gap:8, marginBottom:12}}>
      <input placeholder="Search" value={filters.search} onChange={e => setFilters({...filters, search: e.target.value, page:1})} />
      <select value={filters.sort} onChange={e => setFilters({...filters, sort: e.target.value})}>
        <option value="">Sort</option>
        <option value="price_asc">Price low→high</option>
        <option value="price_desc">Price high→low</option>
      </select>
      <input type="number" placeholder="min" value={filters.minPrice} onChange={e => setFilters({...filters, minPrice: e.target.value})} />
      <input type="number" placeholder="max" value={filters.maxPrice} onChange={e => setFilters({...filters, maxPrice: e.target.value})} />
    </div>
  );
}
