import React, { useContext } from 'react';
import { CartContext } from '../contexts/CartContext';
import { Link } from 'react-router-dom';

export default function ProductCard({ product }) {
  const { addToCart } = useContext(CartContext);
  return (
    <div style={{border:'1px solid #eee', padding:12, borderRadius:6}}>
      <Link to={`/product/${product._id}`}><h3>{product.title}</h3></Link>
      <p>₹{product.price}</p>
      <button onClick={()=>addToCart(product,1)}>Add</button>
    </div>
  );
}
