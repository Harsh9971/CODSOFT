import React from 'react';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import Home from './pages/Home';
import ProductPage from './pages/Product';
import CartPage from './pages/Cart';
import CheckoutPage from './pages/Checkout';
import Login from './pages/Login';
import Register from './pages/Register';
import { AuthProvider } from './contexts/AuthContext';
import { CartProvider } from './contexts/CartContext';

export default function App(){
  return (
    <AuthProvider>
      <CartProvider>
        <BrowserRouter>
          <nav style={{padding:10, borderBottom:'1px solid #ddd'}}>
            <Link to="/" style={{marginRight:10}}>Home</Link>
            <Link to="/cart">Cart</Link>
          </nav>
          <div style={{padding:20}}>
            <Routes>
              <Route path="/" element={<Home/>} />
              <Route path="/product/:id" element={<ProductPage/>} />
              <Route path="/cart" element={<CartPage/>} />
              <Route path="/checkout" element={<CheckoutPage/>} />
              <Route path="/login" element={<Login/>} />
              <Route path="/register" element={<Register/>} />
            </Routes>
          </div>
        </BrowserRouter>
      </CartProvider>
    </AuthProvider>
  );
}
