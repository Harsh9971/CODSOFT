import React, { createContext, useState } from 'react';

export const CartContext = createContext();

export const CartProvider = ({ children }) => {
  const [cart, setCart] = useState(()=> JSON.parse(localStorage.getItem('cart')) || []);

  const addToCart = (product, qty = 1) => {
    setCart(prev => {
      const itemExists = prev.find(i => i.product === product._id);
      let newCart;
      if (itemExists) {
        newCart = prev.map(i => i.product === product._id ? {...i, qty: i.qty + qty} : i);
      } else {
        newCart = [...prev, { product: product._id, title: product.title, price: product.price, qty }];
      }
      localStorage.setItem('cart', JSON.stringify(newCart));
      return newCart;
    });
  };

  const removeFromCart = (productId) => {
    const newCart = cart.filter(i => i.product !== productId);
    localStorage.setItem('cart', JSON.stringify(newCart));
    setCart(newCart);
  };

  const clearCart = () => { localStorage.removeItem('cart'); setCart([]); };

  return <CartContext.Provider value={{ cart, addToCart, removeFromCart, clearCart }}>{children}</CartContext.Provider>;
};
