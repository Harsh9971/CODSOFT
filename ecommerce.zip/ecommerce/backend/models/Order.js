const mongoose = require('mongoose');

const orderSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  items: [{
    product: { type: mongoose.Schema.Types.ObjectId, ref: 'Product' },
    qty: Number,
    price: Number
  }],
  shippingAddress: {
    line1: String, city: String, postalCode: String, country: String
  },
  total: Number,
  paymentStatus: { type: String, enum: ['pending','paid','failed'], default: 'pending' },
  paymentIntentId: String
}, { timestamps: true });

module.exports = mongoose.model('Order', orderSchema);
