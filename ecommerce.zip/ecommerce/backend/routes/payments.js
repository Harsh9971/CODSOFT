const express = require('express');
const router = express.Router();
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY || 'sk_test_dummy');
const auth = require('../middleware/authMiddleware');

router.post('/create-payment-intent', auth, async (req, res) => {
  const { amount, currency = 'inr' } = req.body;
  try {
    const paymentIntent = await stripe.paymentIntents.create({
      amount: Math.round(amount * 100),
      currency,
      metadata: { userId: req.user._id.toString() }
    });
    res.json({ clientSecret: paymentIntent.client_secret, id: paymentIntent.id });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
