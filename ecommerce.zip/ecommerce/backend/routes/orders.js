const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const Order = require('../models/Order');

router.post('/', auth, async (req, res) => {
  const { items, shippingAddress, total, paymentIntentId } = req.body;
  try {
    const order = new Order({
      user: req.user._id,
      items,
      shippingAddress,
      total,
      paymentIntentId,
      paymentStatus: 'pending'
    });
    await order.save();
    res.json(order);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

router.get('/my-orders', auth, async (req, res) => {
  const orders = await Order.find({ user: req.user._id }).populate('items.product');
  res.json(orders);
});

module.exports = router;
