const express = require('express');
const router = express.Router();
const Product = require('../models/Product');

// GET /api/products?category=xxx&minPrice=0&maxPrice=100&search=shirt&brand=Y&sort=price_desc&page=1&limit=12
router.get('/', async (req, res) => {
  const { page=1, limit=12, category, brand, search, minPrice, maxPrice, sort } = req.query;
  const q = {};
  if (category) q.category = category;
  if (brand) q.brand = brand;
  if (search) q.$text = { $search: search };
  if (minPrice || maxPrice) q.price = {};
  if (minPrice) q.price.$gte = Number(minPrice);
  if (maxPrice) q.price.$lte = Number(maxPrice);

  let cursor = Product.find(q);
  if (sort === 'price_asc') cursor = cursor.sort({ price: 1 });
  else if (sort === 'price_desc') cursor = cursor.sort({ price: -1 });
  else if (sort === 'rating_desc') cursor = cursor.sort({ rating: -1 });

  const total = await Product.countDocuments(q);
  const products = await cursor.skip((page-1)*limit).limit(Number(limit));
  res.json({ products, total, page: Number(page), pages: Math.ceil(total/limit) });
});

router.get('/:id', async (req, res) => {
  const p = await Product.findById(req.params.id);
  if (!p) return res.status(404).json({ message: 'Not found' });
  res.json(p);
});

module.exports = router;
