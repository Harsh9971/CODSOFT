require('dotenv').config();
const mongoose = require('mongoose');
const connectDB = require('../config/db');
const Product = require('../models/Product');

const data = [
  { title: 'Blue T-shirt', description: 'Comfort cotton', price: 399, category: 'Clothing', brand: 'BrandA', countInStock: 50 },
  { title: 'Running Shoes', description: 'Comfortable shoes', price: 2499, category: 'Footwear', brand: 'BrandB', countInStock: 30 },
  { title: 'Wireless Headphones', description: 'Noise-canceling', price: 3499, category: 'Electronics', brand: 'BrandC', countInStock: 20 },
  { title: 'Coffee Mug', description: 'Ceramic 350ml', price: 299, category: 'Home', brand: 'BrandD', countInStock: 100 }
];

(async () => {
  await connectDB();
  await Product.deleteMany({});
  await Product.insertMany(data);
  console.log('Seeded');
  process.exit();
})();
