import React from "react";

export default function CandidateDashboard(){
  return (
    <div className="container">
      <h1>Candidate Dashboard</h1>
      <p>Manage profile and applications (requires backend API).</p>
    </div>
  );
}
